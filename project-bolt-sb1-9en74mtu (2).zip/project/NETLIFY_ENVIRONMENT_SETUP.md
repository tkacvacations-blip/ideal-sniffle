# Netlify Deployment - Environment Setup

**Your Site:** https://elaborate-bunny-c1aa97.netlify.app/
**Status:** Deployed ✅
**Next Step:** Configure Environment Variables

---

## 🔧 CRITICAL: Set Environment Variables in Netlify

Your site is deployed but needs environment variables to connect to Supabase and Stripe.

### Step 1: Go to Netlify Dashboard

1. Visit: https://app.netlify.com/sites/elaborate-bunny-c1aa97
2. Click "Site configuration" in the left menu
3. Click "Environment variables"

### Step 2: Add These Variables

Click "Add a variable" and add each of these:

#### Variable 1: VITE_SUPABASE_URL
```
Key: VITE_SUPABASE_URL
Value: https://dihmwdryzulyesdgvzzk.supabase.co
Scopes: All deploy contexts
```

#### Variable 2: VITE_SUPABASE_ANON_KEY
```
Key: VITE_SUPABASE_ANON_KEY
Value: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpaG13ZHJ5enVseWVzZGd2enprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgwMTEzODgsImV4cCI6MjA4MzU4NzM4OH0.4KxcZFbnifbyCyOvzFQkPXi23VUMIZqJkqad7Mwserk
Scopes: All deploy contexts
```

#### Variable 3: VITE_STRIPE_PUBLISHABLE_KEY (Optional)
```
Key: VITE_STRIPE_PUBLISHABLE_KEY
Value: [Your Stripe key - pk_test_ or pk_live_]
Scopes: All deploy contexts
```

### Step 3: Trigger a New Deploy

After adding variables:
1. Go to "Deploys" tab
2. Click "Trigger deploy" → "Clear cache and deploy site"
3. Wait 1-2 minutes

---

## Quick Links

- Site: https://elaborate-bunny-c1aa97.netlify.app/
- Dashboard: https://app.netlify.com/sites/elaborate-bunny-c1aa97
- Environment Variables: https://app.netlify.com/sites/elaborate-bunny-c1aa97/settings/env

**The site won't work until you add these environment variables!**
