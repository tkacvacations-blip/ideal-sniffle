# FORCE NETLIFY TO REDEPLOY WITH PROMO CODE

## The Problem
Netlify is serving cached old files that don't have the promo code field.

## The Solution - FORCE A CLEAN REDEPLOY

### Method 1: Trigger Redeploy in Netlify Dashboard (EASIEST)

1. Go to your Netlify dashboard
2. Click on your site
3. Go to **Deploys** tab
4. Click **Trigger deploy** dropdown button (top right)
5. Select **"Deploy site"**
6. Wait for the deployment to complete (2-3 minutes)
7. **CRITICAL**: Clear your browser cache:
   - Chrome/Edge: Press `Ctrl + Shift + Delete`, select "Cached images and files", click "Clear data"
   - Or do a hard refresh: `Ctrl + F5` or `Ctrl + Shift + R`

### Method 2: Clear Cache & Redeploy (MORE THOROUGH)

1. Go to your Netlify dashboard
2. Click on your site
3. Go to **Site configuration** → **General** → **Asset optimization**
4. Click **"Purge cache and deploy site"**
5. Wait for deployment to complete
6. Clear your browser cache as described above

### Method 3: Git Push (IF YOU HAVE GIT SETUP)

If your site is connected to a Git repository:
```bash
git add .
git commit -m "Add promo code field to rental modal"
git push
```

This will automatically trigger a Netlify deployment.

## After Deployment

1. **MUST CLEAR BROWSER CACHE** - The old JavaScript files are cached in your browser
2. Visit your site URL
3. Click on a beach house rental
4. You should now see the "Promo Code (Optional)" field

## What Was Fixed

The promo code field has been added to the `AddPropertyToCartModal` component with:
- Automatic detection of promo codes from URL (?promo=CODE)
- Apply/Remove buttons
- Discount calculation and display
- Validation against the database
- Usage tracking when codes are applied

## Test It

After clearing cache, try this URL (replace YOUR-SITE with your actual domain):
```
https://YOUR-SITE.netlify.app/?promo=TEST20
```

The promo code "TEST20" should automatically appear in the field when you open the rental modal.
