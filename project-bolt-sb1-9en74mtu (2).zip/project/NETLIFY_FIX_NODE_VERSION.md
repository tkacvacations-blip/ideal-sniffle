# Fix Netlify Node Version Issue

If your site shows errors, check the Node version in Netlify.

## Quick Fix

1. Go to: https://app.netlify.com/sites/elaborate-bunny-c1aa97/settings/deploys
2. Scroll to "Build settings"
3. Look for "Environment variables" section
4. Add if not present:
   - Key: `NODE_VERSION`
   - Value: `20.11.1`

5. Go to Deploys tab
6. Click "Trigger deploy" → "Clear cache and deploy site"

This ensures Netlify uses the correct Node version (20.x) that matches your project requirements.
