# Netlify Setup Checklist

Your site: https://elaborate-bunny-c1aa97.netlify.app/

## Setup Steps (5 minutes)

### 1. Set Environment Variables
Go to: https://app.netlify.com/sites/elaborate-bunny-c1aa97/settings/env

Add these 3 variables:

```
VITE_SUPABASE_URL
https://dihmwdryzulyesdgvzzk.supabase.co

VITE_SUPABASE_ANON_KEY
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpaG13ZHJ5enVseWVzZGd2enprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgwMTEzODgsImV4cCI6MjA4MzU4NzM4OH0.4KxcZFbnifbyCyOvzFQkPXi23VUMIZqJkqad7Mwserk

VITE_STRIPE_PUBLISHABLE_KEY (optional for now)
[your stripe key]
```

### 2. Verify Node Version
Go to: https://app.netlify.com/sites/elaborate-bunny-c1aa97/settings/deploys

Check NODE_VERSION is set to `20.11.1` (should be set via netlify.toml)

### 3. Trigger Deploy
Go to: https://app.netlify.com/sites/elaborate-bunny-c1aa97/deploys

Click: "Trigger deploy" → "Clear cache and deploy site"

### 4. Wait & Test
Wait 1-2 minutes, then visit your site and test:
- Site loads
- Properties appear
- Calendar works
- Can add to cart
- Checkout shows promo field

## Done!

Your site should now be fully functional.
