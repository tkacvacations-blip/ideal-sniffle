# 🔧 Netlify Environment Setup

## Copy-Paste These Into Netlify

Go to: https://app.netlify.com/sites/elaborate-bunny-c1aa97/settings/env

---

### Environment Variable 1

**Key:**
```
VITE_SUPABASE_URL
```

**Value:**
```
https://dihmwdryzulyesdgvzzk.supabase.co
```

**Scopes:** ✓ All deploy contexts

---

### Environment Variable 2

**Key:**
```
VITE_SUPABASE_ANON_KEY
```

**Value:**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpaG13ZHJ5enVseWVzZGd2enprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgwMTEzODgsImV4cCI6MjA4MzU4NzM4OH0.4KxcZFbnifbyCyOvzFQkPXi23VUMIZqJkqad7Mwserk
```

**Scopes:** ✓ All deploy contexts

---

### Environment Variable 3 (Optional - for Stripe)

**Key:**
```
VITE_STRIPE_PUBLISHABLE_KEY
```

**Value:**
```
[Your Stripe publishable key - starts with pk_test_ or pk_live_]
```

**Scopes:** ✓ All deploy contexts

---

## After Adding Variables

1. Go to: https://app.netlify.com/sites/elaborate-bunny-c1aa97/deploys
2. Click "Trigger deploy"
3. Select "Clear cache and deploy site"
4. Wait 1-2 minutes
5. Test your site!

---

**Your Site:** https://elaborate-bunny-c1aa97.netlify.app/
